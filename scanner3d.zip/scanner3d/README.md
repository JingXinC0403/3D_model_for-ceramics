# SCAN3D — Browser-Based 3D Scanning System

A full-stack web application that captures photos from your browser camera,
uploads them to a Node.js backend, runs a photogrammetry pipeline, and displays
the resulting 3D model in the browser using Three.js.

---

## Project Structure

```
scanner3d/
├── server.js                  # Express entry point
├── package.json
├── routes/
│   ├── upload.js              # Frame upload endpoints (multer)
│   └── scan.js                # Job management & polling endpoints
├── lib/
│   └── photogrammetry.js      # Pipeline runner (simulated + OBJ/GLB generator)
├── public/
│   ├── index.html             # Single-page frontend
│   ├── style.css              # Industrial-tech dark theme
│   └── app.js                 # Camera, upload, polling, Three.js viewer
├── uploads/                   # Auto-created — raw frames per session
└── output/                    # Auto-created — OBJ, MTL, GLB, texture per job
```

---

## Quick Start

### Prerequisites
- **Node.js** v18+ — https://nodejs.org
- A browser with camera access (Chrome, Firefox, Edge, Safari)
- A camera (built-in webcam or phone camera)

### 1. Install dependencies
```bash
cd scanner3d
npm install
```

### 2. Start the server
```bash
npm start
# or for auto-reload during development:
npm run dev
```

You should see:
```
🔷 3D Scanner Server running at http://localhost:3000
📁 Uploads: .../scanner3d/uploads
📦 Output:  .../scanner3d/output
```

### 3. Open the app
Navigate to **http://localhost:3000** in your browser.

> ⚠️ Camera access requires HTTPS or localhost. The app works on localhost out of the box.
> For remote access, put it behind nginx with a TLS certificate.

---

## How It Works

### Step 1 — Capture
- The app requests camera access via `getUserMedia`
- You configure how many frames (5–30) and the interval between captures
- Click **Start Scan** — frames are automatically captured and uploaded one by one
- Each frame is sent to `POST /api/upload/frame` with your session ID

### Step 2 — Processing
- After all frames are uploaded, the app calls `POST /api/scan/process`
- The backend queues a job and runs the photogrammetry pipeline
- The frontend polls `GET /api/scan/status/:jobId` every 600ms
- Pipeline stages are shown in a live terminal + progress bar

### Step 3 — View
- When processing completes, the GLB model loads in the Three.js viewer
- You can rotate, zoom, and pan the model
- Download the model as OBJ or GLB

---

## API Reference

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET    | `/api/health` | Server health check |
| POST   | `/api/upload/frame` | Upload single frame |
| POST   | `/api/upload/batch` | Upload all frames at once |
| GET    | `/api/upload/session/:id` | List frames for a session |
| POST   | `/api/scan/process` | Start 3D reconstruction |
| GET    | `/api/scan/status/:jobId` | Poll job progress |
| GET    | `/api/scan/jobs` | List all jobs |
| DELETE | `/api/scan/job/:jobId` | Clean up a job |
| GET    | `/output/:jobId/model.obj` | Download OBJ |
| GET    | `/output/:jobId/model.glb` | Download GLB |
| GET    | `/output/:jobId/texture.jpg` | Download texture |

### Upload frame headers
```
x-session-id: sess_abc123   (required — groups frames into one scan)
x-frame-index: 0            (optional — determines filename ordering)
```

---

## Output Files (per job)
| File | Description |
|------|-------------|
| `model.obj` | Wavefront OBJ mesh |
| `model.mtl` | Material library |
| `texture.jpg` | Procedural texture (512×512) |
| `model.glb` | Binary glTF (loads directly in Three.js) |
| `stats.json` | Reconstruction metadata |

---

## Replacing the Simulated Pipeline with Real Photogrammetry

The pipeline in `lib/photogrammetry.js` is currently simulated. To use a real engine:

### Option A — COLMAP (local, free)
```bash
# Install COLMAP: https://colmap.github.io/install.html
# Then replace the `run` function body with:
const { execSync } = require('child_process');
execSync(`colmap automatic_reconstructor --workspace_path ${outputDir} --image_path ${uploadDir}`);
```

### Option B — OpenMVG + OpenMVS (local, free)
Install from https://github.com/openMVG/openMVG and call binaries via `child_process.execFile`.

### Option C — Meshroom / AliceVision (local, GUI or CLI)
```bash
meshroom_batch --input ${uploadDir} --output ${outputDir}
```

### Option D — Cloud API (Polycam, RealityCapture, etc.)
Replace the `run` function with an HTTP call to your cloud provider's API.
Upload the frames as a ZIP, poll for completion, download the resulting model.

---

## Tips for Better Scan Quality

| Tip | Why |
|-----|-----|
| Capture 15–30 frames | More coverage = better reconstruction |
| Walk slowly in a circle around the object | Ensures all angles are covered |
| Keep the object in good, even lighting | Shadows confuse feature matching |
| Avoid shiny or transparent surfaces | They have no texture features |
| Keep background stable | Moving backgrounds mislead structure-from-motion |
| Use a slow interval (1.5–2s) | Gives time for the frame to be sharp |

---

## Troubleshooting

**"Server offline" badge** → Run `npm start` in the project directory.

**"Camera access required"** → Allow camera in browser permissions. Try Chrome on localhost.

**Upload fails** → Check that the `uploads/` folder is writable. The server creates it automatically.

**Model doesn't load** → Open browser console (F12). GLB parse errors are logged there.

**Sharp not installed** → Run `npm install sharp`. Falls back to a 1×1 pixel JPEG if unavailable.

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | HTML5, CSS3, Vanilla JS |
| 3D Rendering | Three.js r128 |
| Camera | `getUserMedia` API |
| Backend | Node.js + Express |
| File uploads | Multer |
| Image processing | Sharp (optional) |
| 3D pipeline | Simulated (swap for COLMAP/OpenMVG) |
| Model formats | OBJ + MTL + GLB (binary glTF 2.0) |
